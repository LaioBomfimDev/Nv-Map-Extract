// Gerado por scripts/release-extension.mjs. A chave anon é pública e protegida por RLS.
const FM_CONFIG = Object.freeze({
  "SUPABASE_URL": "https://obxjhhevvbjramnziura.supabase.co",
  "SUPABASE_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9ieGpoaGV2dmJqcmFtbnppdXJhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODMzNDQ2NzcsImV4cCI6MjA5ODkyMDY3N30.hCH5Hskgibmp2ThJpioSVdm3KQ8p5w3yPXa-IEvMRaw",
  "APP_URL": "https://nv-map-extract.vercel.app"
});
